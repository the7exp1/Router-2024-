// Wait for IndexedDB to be ready before performing any actions
document.addEventListener("indexedDBReady", () => {
    if (!dbInstance) {
        console.error("IndexedDB is not initialized.");
        alert("Unable to access project data. Please try reloading the page.");
        return;
    }
    loadSavedRoutes();
});

// Function to save the current route to IndexedDB
function saveCurrentRoute(routeName) {
    if (!dbInstance) {
        console.error("IndexedDB is not initialized.");
        return;
    }

    const routeData = {
        routeName,
        waypoints: window.stopsArray,
    };

    const transaction = dbInstance.transaction("routes", "readwrite");
    const store = transaction.objectStore("routes");

    store.put(routeData);

    transaction.oncomplete = () => {
        console.log(`Route "${routeName}" saved successfully in IndexedDB.`);
    };

    transaction.onerror = (event) => {
        console.error(`Error saving route "${routeName}":`, event.target.error);
    };
}

// Function to load saved routes from IndexedDB
function loadSavedRoutes() {
    if (!dbInstance) {
        console.error("IndexedDB is not initialized.");
        return;
    }

    const transaction = dbInstance.transaction("routes", "readonly");
    const store = transaction.objectStore("routes");
    const getAllRequest = store.getAll();

    getAllRequest.onsuccess = () => {
        const savedRoutes = getAllRequest.result;
        if (savedRoutes && savedRoutes.length > 0) {
            console.log("Loaded saved routes from IndexedDB:", savedRoutes);
            updateMainSidebar(savedRoutes);
        } else {
            console.log("No saved routes found in IndexedDB.");
        }
    };

    getAllRequest.onerror = () => {
        console.error("Error retrieving saved routes from IndexedDB.");
    };
}

// Function to update the main sidebar with saved routes
function updateMainSidebar(savedRoutes = []) {
    const routeListContainer = document.getElementById('routeList');
    if (!routeListContainer) return;

    routeListContainer.innerHTML = '';

    savedRoutes.forEach((route) => {
        const button = document.createElement('button');
        button.classList.add('route-button');
        button.textContent = route.routeName;

        button.addEventListener('contextmenu', (event) => {
            event.preventDefault();
            showDeleteModal(route.routeName);
        });

        routeListContainer.appendChild(button);
    });

    console.log("Main sidebar updated with saved routes.");
}

// Function to load a route from IndexedDB
function loadRoute(routeName) {
    if (!dbInstance) {
        console.error("IndexedDB is not initialized.");
        return;
    }

    const transaction = dbInstance.transaction("routes", "readonly");
    const store = transaction.objectStore("routes");
    const getRequest = store.get(routeName);

    getRequest.onsuccess = () => {
        const selectedRoute = getRequest.result;
        if (selectedRoute) {
            console.log("Loading route:", selectedRoute);
            displayRouteOnMap(selectedRoute);
        } else {
            console.error(`Route "${routeName}" not found in IndexedDB.`);
        }
    };

    getRequest.onerror = () => {
        console.error(`Error loading route "${routeName}" from IndexedDB.`);
    };
}

// Function to display a route on the map
function displayRouteOnMap(route) {
    if (window.routingControl) {
        window.map.removeControl(window.routingControl);
        console.log("Existing routing control removed.");
    }

    const waypoints = route.waypoints.map((wp) => L.latLng(wp.lat, wp.lng));
    window.routingControl = L.Routing.control({
        waypoints: waypoints,
        createMarker: () => null,
        routeWhileDragging: true,
    }).addTo(window.map);

    window.savedStopsLayer = L.layerGroup();
    route.stops.forEach((stop) => {
        const marker = L.circleMarker([stop.stop_lat, stop.stop_lon], {
            radius: 5,
            color: 'green',
        }).bindPopup(stop.stop_name);
        window.savedStopsLayer.addLayer(marker);
    });
    window.savedStopsLayer.addTo(window.map);

    updateRouteInfo(route.length, route.stops.length);
    console.log(`Route "${route.routeName}" displayed on the map.`);
}

// Function to delete a route from IndexedDB
function deleteRoute(routeName) {
    if (!dbInstance) {
        console.error("IndexedDB is not initialized.");
        return;
    }

    const transaction = dbInstance.transaction("routes", "readwrite");
    const store = transaction.objectStore("routes");

    store.delete(routeName);

    transaction.oncomplete = () => {
        console.log(`Route "${routeName}" deleted successfully from IndexedDB.`);
        updateMainSidebar();
    };

    transaction.onerror = (event) => {
        console.error(`Error deleting route "${routeName}":`, event.target.error);
    };
}

// Function to show the delete confirmation modal
function showDeleteModal(routeName) {
    const modal = document.getElementById("deleteModal");
    const modalText = document.getElementById("modalText");
    const confirmDeleteButton = document.getElementById("confirmDeleteButton");
    const cancelDeleteButton = document.getElementById("cancelDeleteButton");

    modalText.textContent = `Are you sure you want to delete the route "${routeName}"?`;
    modal.classList.add("show-modal");

    confirmDeleteButton.onclick = () => {
        deleteRoute(routeName);
        closeModal();
    };

    cancelDeleteButton.onclick = closeModal;
}

// Function to close the delete modal
function closeModal() {
    const modal = document.getElementById("deleteModal");
    modal.classList.remove("show-modal");
    setTimeout(() => {
        modal.style.display = "none";
    }, 300);
}