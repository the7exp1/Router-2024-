// Event listener for the GTFS import button
document.getElementById("importGTFS").addEventListener("click", () => {
    document.getElementById("gtfsFileInput").click();
});

// Event listener for GTFS file input change
document.getElementById("gtfsFileInput").addEventListener("change", async (event) => {
    const file = event.target.files[0];

    if (!file) {
        alert("No file selected!");
        return;
    }

    if (!file.name.endsWith(".zip")) {
        alert("Please select a valid GTFS .zip file.");
        return;
    }

    try {
        // Load the zip file using JSZip
        const zip = await JSZip.loadAsync(file);
        const files = zip.files;

        // Ensure required GTFS files exist
        const stopsFile = files["stops.txt"];
        const routesFile = files["routes.txt"];
        const stopTimesFile = files["stop_times.txt"];
        const shapesFile = files["shapes.txt"];

        if (!stopsFile || !routesFile || !stopTimesFile || !shapesFile) {
            alert("Missing required GTFS files (stops.txt, routes.txt, stop_times.txt, shapes.txt).");
            return;
        }

        // Read and parse the contents of the files
        const stopsText = await stopsFile.async("text");
        const routesText = await routesFile.async("text");
        const stopTimesText = await stopTimesFile.async("text");
        const shapesText = await shapesFile.async("text");

        const stopsData = parseCSV(stopsText);
        const routesData = parseCSV(routesText);
        const stopTimesData = parseCSV(stopTimesText);
        const shapesData = parseCSV(shapesText);

        // Format the data
        const formattedStops = formatStops(stopsData);
        const formattedRoutes = formatRoutes(routesData);
        const formattedStopTimes = formatStopTimes(stopTimesData);
        const formattedShapes = formatShapes(shapesData);

        // Open IndexedDB and store the formatted data
        const request = indexedDB.open("routerDB", 1);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains("stops")) {
                db.createObjectStore("stops", { keyPath: "stop_id" });
            }
            if (!db.objectStoreNames.contains("routes")) {
                db.createObjectStore("routes", { keyPath: "route_id" });
            }
            if (!db.objectStoreNames.contains("stopTimes")) {
                db.createObjectStore("stopTimes", { keyPath: "trip_id" });
            }
            if (!db.objectStoreNames.contains("shapes")) {
                db.createObjectStore("shapes", { keyPath: "shape_id" });
            }
        };

        request.onsuccess = (event) => {
            const db = event.target.result;
            storeDataInIndexedDB(db, "stops", formattedStops);
            storeDataInIndexedDB(db, "routes", formattedRoutes);
            storeDataInIndexedDB(db, "stopTimes", formattedStopTimes);
            storeDataInIndexedDB(db, "shapes", formattedShapes);
        };

        request.onerror = () => {
            console.error("Failed to open IndexedDB.");
            alert("An error occurred while accessing the database.");
        };

    } catch (error) {
        console.error("Error processing the GTFS file:", error);
        alert("An error occurred while processing the GTFS file.");
    }
});

// Parse CSV content into an array of objects
function parseCSV(csvText) {
    const rows = csvText.split("\n").map(row => row.trim()).filter(row => row);
    const headers = rows[0].split(",");
    return rows.slice(1).map(row => {
        const values = row.split(",");
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = values[index];
        });
        return obj;
    });
}

// Function to format the stops data
function formatStops(stopsData) {
    return stopsData.map(stop => ({
        stop_id: stop.stop_id,
        stop_name: stop.stop_name,
        stop_lat: parseFloat(stop.stop_lat),
        stop_lon: parseFloat(stop.stop_lon),
    }));
}

// Function to format the routes data
function formatRoutes(routesData) {
    return routesData.map(route => ({
        route_id: route.route_id,
        route_name: route.route_desc || route.route_long_name || route.route_short_name,
        route_type: route.route_type,
    }));
}

// Function to format the stop times data
function formatStopTimes(stopTimesData) {
    return stopTimesData.map(stopTime => ({
        trip_id: stopTime.trip_id,
        stop_id: stopTime.stop_id,
        arrival_time: stopTime.arrival_time,
        departure_time: stopTime.departure_time,
        stop_sequence: parseInt(stopTime.stop_sequence),
    }));
}

// Function to format the shapes data
function formatShapes(shapesData) {
    return shapesData.map(shape => ({
        shape_id: shape.shape_id,
        shape_pt_lat: parseFloat(shape.shape_pt_lat),
        shape_pt_lon: parseFloat(shape.shape_pt_lon),
        shape_pt_sequence: parseInt(shape.shape_pt_sequence),
    }));
}

// Function to store data in IndexedDB
function storeDataInIndexedDB(db, storeName, data) {
    const transaction = db.transaction([storeName], "readwrite");
    const objectStore = transaction.objectStore(storeName);

    data.forEach(item => {
        objectStore.put(item);
    });

    transaction.oncomplete = () => {
        console.log(`${storeName} data saved successfully.`);
        alert(`${storeName} data imported successfully.`);
    };

    transaction.onerror = (event) => {
        console.error(`Error storing ${storeName} data:`, event.target.error);
        alert(`Failed to store ${storeName} data.`);
    };
}

// Function to render the routes in the UI
function renderRoutes(routes) {
    const routeButtonsContainer = document.getElementById("routeButtons");
    routeButtonsContainer.innerHTML = "";

    routes.forEach(route => {
        const routeButton = document.createElement("button");
        routeButton.textContent = route.route_name;
        routeButton.classList.add("route-btn");
        routeButton.addEventListener("click", () => {
            console.log(`Route clicked: ${route.route_name}`);
        });
        routeButtonsContainer.appendChild(routeButton);
    });
}

// Function to render the routes on the map
function renderMapRoutes(routes, shapes) {
    routes.forEach(route => {
        const routeShape = shapes.filter(shape => shape.shape_id === route.route_id);
        if (routeShape.length > 0) {
            const latlngs = routeShape.map(shape => [shape.shape_pt_lat, shape.shape_pt_lon]);
            L.polyline(latlngs, { color: "blue" }).addTo(map);
        }
    });
}